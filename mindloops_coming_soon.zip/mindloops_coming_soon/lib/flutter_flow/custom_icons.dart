import 'package:flutter/widgets.dart';

class FFIcons {
  FFIcons._();

  static const String _test2Family = 'Test2';

  // test2
  static const IconData khome2 = IconData(0xe904, fontFamily: _test2Family);
  static const IconData kcalmIcon = IconData(0xe900, fontFamily: _test2Family);
  static const IconData krelax = IconData(0xe901, fontFamily: _test2Family);
  static const IconData kfocus = IconData(0xe902, fontFamily: _test2Family);
  static const IconData khamburger = IconData(0xe903, fontFamily: _test2Family);
  static const IconData ksounds = IconData(0xe905, fontFamily: _test2Family);
}
